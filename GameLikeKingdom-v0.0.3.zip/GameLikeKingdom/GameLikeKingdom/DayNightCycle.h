#pragma once
#include "Parallax.h"

class DayNightCycle : Parallax
{
private:
	Uint8 r = 255, g = 0, b = 0;
	bool a = true;
public:
	void Cycle()
	{
		if (r > 0 && g != 255 && a)
		{
			r--;
			g++;
			std::cout << "R-- " << unsigned(r) << " G++ " << unsigned(g) << std::endl;
		}
		else if (g > 0 && b != 255)
		{
			g--;
			b++;
			std::cout << "G-- " << unsigned(g) << " B++ " << unsigned(b) << std::endl;
		}
		else if (b > 0 && r != 255)
		{
			b--;
			r++;
			std::cout << "B-- " << unsigned(b) << " R++ " << unsigned(r) << std::endl;
		}

		if (b == 0)
			a = true;
		else
			a = false;

	}

	Uint8 GetR()
	{
		return r;
	}
	Uint8 GetG()
	{
		return g;
	}
	Uint8 GetB()
	{
		return b;
	}
};