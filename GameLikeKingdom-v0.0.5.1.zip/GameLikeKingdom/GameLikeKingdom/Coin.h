#pragma once
#include "GameObject.h"

class Coin : public GameObject
{
private:
	bool mini = false;
	bool canPickup = false;
	bool holding = false;
	int pickupTimer = 0;
	int id;
public:
	SDL_Rect src = { 0, 0, 64, 64 };
	SDL_Rect dst = { 0, 0, 64, 64 };
	Coin(GameObject& go, int n, bool m = false)
	{
		if (m)
			dst = { 0, 0, 16, 16 };
		id = n;
		Drop(go);
		//UpdatePosition(m_x, m_y);
	}
	~Coin(){}

	void Render(SDL_Renderer* renderer, SDL_Texture* texture)
	{
		SDL_RenderCopy(renderer, texture, &src, &dst);
	}
	void Update(int camX)
	{
		//gravity
		if (!holding)
			dst.y += 10;


		//pickup timer
		if (!holding)
		{
			if (pickupTimer < 200)
			{
				pickupTimer++;

			}
			else
				canPickup = true;
		}
		if (!holding) 
		{
			dst.x = m_x - camX;
		}
		else
		{
			canPickup = false;
			pickupTimer = -1;
			dst.x = m_x;
		}
		//std::cout << ">" << canPickup << std::endl;
		//UpdatePosition(m_x, m_y);
	}
	void UpdatePosition(int x, int y)
	{
		dst.x = x;
		dst.y = y;
	}

	void IsMini(bool _mini)
	{
		mini = _mini;
		if (mini)
			dst.w = dst.h = 24;
		else
			dst.w = dst.h = 32;
	}

	void Pickup(int n)
	{
		if (canPickup)
		{
			//std::cout << "canPickup && !holding, timer: " << pickupTimer << std::endl;
			IsMini(true);
			if (n < 5)
				m_x = 750 + 24 * n;
			else
				m_x = 750 + 24 * (n - 5);
			if (n < 5)
				m_y = 30;
			else
				m_y = 60;
			holding = true;
			UpdatePosition(m_x, m_y);
			std::cout << m_x << " " << m_y << std::endl;
		}
	}
	void Drop(GameObject& go)
	{
		IsMini(false);
		m_x = go.m_x + 64;
		dst.y = go.m_y - 100;
		pickupTimer = 0;
		holding = false;
		canPickup = false;
		//std::cout << m_x << " " << m_y << " " << go.m_x << " " << go.m_y << " " << dst.x << " " << dst.y << std::endl;
	}

	bool CanPickup()
	{
		//std::cout << "cP " << canPickup << " h" << holding << std::endl;
		bool temp;
		if (canPickup && !holding)
		{
			//std::cout << "E" << std::endl;
			temp = true;
		}
		else
		{
			//std::cout << "!" << std::endl;
			temp = false;
		}
		return temp;
	}
	int GetTimer()
	{
		return pickupTimer;
	}

	int GetID()
	{
		return id;
	}

	void Delete()
	{

	}
};