#include <chrono>
#include <iostream>
#include "Game.h"
#include "Player.h"
#include "DayNightCycle.h"
using namespace std;
using namespace chrono;

bool Game::init(const char* title, int xpos, int ypos, int width,
	int height, int flags)
{
	// Attempt to initialize SDL.
	if (SDL_Init(SDL_INIT_EVERYTHING) == 0)
	{
		cout << "SDL init success" << endl;
		// Init the window.
		m_pWindow = SDL_CreateWindow(title, xpos, ypos, width, height, flags);
		if (m_pWindow != 0) // Window init success.
		{
			cout << "Window creation successful" << endl;
			m_pRenderer = SDL_CreateRenderer(m_pWindow, -1, 0);
			if (m_pRenderer != 0) // Renderer init success.
			{
				cout << "renderer creation success" << endl;
				SDL_SetRenderDrawColor(m_pRenderer, 0, 0, 0, 255);
			}
			else
			{
				cout << "renderer init fail" << endl;
				return false; // Renderer init fail.
			}
		}
		else
		{
			cout << "window init fail" << endl;
			return false; // Window init fail.
		}
		IMG_Init(IMG_INIT_PNG); // Initializing image system.
		m_sPlayer = IMG_Load("Images/Player.png");
		if (m_sPlayer == 0)
		{
			cout << "player load fail" << endl;
			return false;
		}
		m_tPlayer = SDL_CreateTextureFromSurface(m_pRenderer, m_sPlayer);
		m_sCoin = IMG_Load("Images/Coin.png");
		if (m_sCoin == 0)
		{
			cout << "coin load fail" << endl;
		}
		m_tCoin = SDL_CreateTextureFromSurface(m_pRenderer, m_sCoin);
		m_sPouch = IMG_Load("Images/Pouch.png");
		if (m_sPouch == 0)
		{
			cout << "pouch load fail" << endl;
		}
		m_tPouch = SDL_CreateTextureFromSurface(m_pRenderer, m_sPouch);
		//Enemy
		m_sEnemy= IMG_Load("Images/Robot_Enemy.png");
		if (m_sEnemy == 0)
		{
			cout << "enemy load fail" << endl;
		}
		m_tPouch = SDL_CreateTextureFromSurface(m_pRenderer, m_sEnemy);

		parallax.LoadImages(m_pRenderer);
		SDL_FreeSurface(m_sPlayer);
		SDL_FreeSurface(m_sCoin);
		SDL_FreeSurface(m_sPouch);
		SDL_FreeSurface(m_sEnemy);
		SDL_FreeSurface(parallax.Ground.m_sBackground);
		SDL_FreeSurface(parallax.Background1.m_sBackground);
		SDL_FreeSurface(parallax.Background2.m_sBackground);
		SDL_FreeSurface(parallax.Clouds.m_sBackground);
		SDL_FreeSurface(parallax.Sky.m_sBackground);
	}
	else
	{
		cout << "SDL init fail" << endl;
		return false; // SDL init fail.
	}
	cout << "init success" << endl;
	m_bRunning = true; // Everything is okay, start the engine.
	return true;
}

bool Game::running()
{
	return m_bRunning;
}

bool Game::tick()
{
	auto duration = steady_clock::now().time_since_epoch();

	auto count = duration_cast<microseconds>(duration).count();
	int tick = 1000000 / m_iFPS;

	if (count % tick < 100)
	{
		if (m_bGotTick == false)
		{
			m_bGotTick = true;
			//cout << "Tick " << tick << " @ " << count << endl;
			return true;
		}
		return false;
	}
	else m_bGotTick = false;
	return false;
}

void Game::update(Player& p)
{
	//cout << "player x y: " << p.m_x << " " << p.m_y << endl;
	camera.setCamera(p);
	parallax.ParallaxEverything(camera);
	if (spawnCoin)
	{
		SpawnCoin(p);
		spawnCoin = false;
	}
	CheckCoin(coins, p);
	for (int i = 0; i < coins.size(); i++)
	{
		coins[i]->Update(camera.camera.x);
		/*if (coins[i]->CanPickup() == false)
		{
			coins[i]->Update(camera.camera.x);
			//coins[i]->dst.x = coins[i]->m_x - camera.camera.x;
		}
		else
		{
			coins[i]->dst.x = coins[i]->m_x;
			//std::cout << "Can pickup coin: " << i << endl;
		}*/
		if (coins[i]->dst.y >= 590) coins[i]->dst.y = 590;
	}

	if (spawnEnemy)
	{
		SpawnEnemy(p);
		spawnCoin = false;
	}


	if (m_bLeftPressed)
	{
		p.MoveX(-1);
		p.m_bRight = false;
	}
	if (m_bRightPressed)
	{
		p.MoveX(1);
		p.m_bRight = true;
	}

	if (m_bSpeedUp)
	{
		p.m_iSpeed++;
		m_bSpeedUp = false;
	}

	if (m_bUpPressed || m_bDownPressed || m_bLeftPressed || m_bRightPressed)
	{
		if (m_iTickCtr == m_iTickMax)
		{
			m_iTickCtr = 0;
			p.AdvanceAnim();
		}
		m_iTickCtr++;
	}
	else
	{
		m_iTickCtr = 0;
		p.SetIdle();
	}

	if (p.m_x >= 7667) p.m_x = 7667;
	if (p.m_x <= 495) p.m_x = 495;
	if (p.m_y != 550) p.m_y = 550;
}

void Game::handleEvents(Player& p)
{
	SDL_Event event;

	while (SDL_PollEvent(&event))
	{
		switch (event.type)
		{
		case SDL_QUIT:
			m_bRunning = false;
			break;
		case SDL_KEYDOWN:
			switch (event.key.keysym.sym)
			{
			case 'w':
			case 'W':
				m_bUpPressed = true;
				break;
			case 's':
			case 'S':
				m_bDownPressed = true;
				break;
			case 'a':
			case 'A':
				m_bLeftPressed = true;
				break;
			case 'd':
			case 'D':
				m_bRightPressed = true;
				break;
			case 'e':
			case 'E':
				cout << p.m_x << " " << p.m_y << endl << p.m_rDst.x << " " << p.m_rDst.y << endl << p.m_iSpeed << endl << endl;
				break;
			}
			break;
		case SDL_KEYUP:
			switch (event.key.keysym.sym)
			{
			case 'w':
			case 'W':
				m_bUpPressed = false;
				break;
			case 's':
			case 'S':
				m_bDownPressed = false;
				break;
			case 'a':
			case 'A':
				m_bLeftPressed = false;
				break;
			case 'd':
			case 'D':
				m_bRightPressed = false;
				break;
			case '=':
				spawnCoin = true;
				break;
			case ' ':
				DropCoin(p);
				break;
			case 't':
				CoinStats();
				break;
			}
			break;
		case SDL_MOUSEBUTTONDOWN:
			switch (event.button.clicks)
			{
			case 1:
				SDL_GetMouseState(&x, &y);
				cout << x << " " << y << endl;
			}
		}
	}
}

void Game::render(Player& p)
{
	SDL_RenderClear(m_pRenderer);

	cycle.Cycle();
	SDL_SetTextureColorMod(parallax.Sky.m_tBackground, cycle.GetR(), cycle.GetG(), cycle.GetB());

	SDL_RenderCopy(m_pRenderer, parallax.Sky.m_tBackground,         &parallax.Sky.m_rBackgroundSrc,         &parallax.Sky.m_rBackgroundDst);
	SDL_RenderCopy(m_pRenderer, parallax.Clouds.m_tBackground,      &parallax.Clouds.m_rBackgroundSrc,      &parallax.Clouds.m_rBackgroundDst);
	SDL_RenderCopy(m_pRenderer, parallax.Background2.m_tBackground, &parallax.Background2.m_rBackgroundSrc, &parallax.Background2.m_rBackgroundDst);
	SDL_RenderCopy(m_pRenderer, parallax.Background1.m_tBackground, &parallax.Background1.m_rBackgroundSrc, &parallax.Background1.m_rBackgroundDst);
	SDL_RenderCopy(m_pRenderer, parallax.Ground.m_tBackground,      &parallax.Ground.m_rBackgroundSrc,      &parallax.Ground.m_rBackgroundDst);
	// Things under this will be rendered in front of all the background and ground layers

	//Player
	SDL_RenderCopyEx(m_pRenderer, m_tPlayer, p.GetSrc(), p.GetDst(), 0, 0, (p.m_bRight ? SDL_FLIP_NONE : SDL_FLIP_HORIZONTAL));

	//Coins
	for (int i = 0; i < (int)coins.size(); i++)
	{
		coins[i]->Render(m_pRenderer, m_tCoin);
	}

	//Enemy
	SDL_RenderCopyEx(m_pRenderer, m_tEnemy, p.GetSrc(), p.GetDst(), 0, 0, (p.m_bRight ? SDL_FLIP_NONE : SDL_FLIP_HORIZONTAL));

	SDL_RenderPresent(m_pRenderer);
}

void Game::clean()
{
	SDL_DestroyTexture(m_tPlayer);

	// Deallocating parallaxed sprites
	SDL_DestroyTexture(parallax.Ground.m_tBackground);
	SDL_DestroyTexture(parallax.Background1.m_tBackground);
	SDL_DestroyTexture(parallax.Background2.m_tBackground);
	SDL_DestroyTexture(parallax.Clouds.m_tBackground);
	SDL_DestroyTexture(parallax.Sky.m_tBackground);
	SDL_DestroyTexture(m_tCoin);
	SDL_DestroyTexture(m_tPouch);
	SDL_DestroyTexture(m_tEnemy);


	//destroy all coins
	for (int i = 0; i < (int)coins.size(); i++)
	{
		delete coins[i];
		coins[i] = nullptr;
	}
	coins.clear();
	coins.shrink_to_fit();

	SDL_DestroyRenderer(m_pRenderer);
	SDL_DestroyWindow(m_pWindow);
	IMG_Quit();
	SDL_Quit();
}

// All the coins

void Game::SpawnCoin(GameObject& go)
{
	coins.push_back(new Coin(go, coins.size()));
	cout << "+Spawned coin " << (int)coins.size() - 1 << " with ID: " << coins[coins.size() - 1]->GetID() << endl;
}

void Game::DropCoin(GameObject& go)
{
	if (coinCount != 0)
	{
		for (int i = 0; i < coins.size(); i++)
		{
			if (coins[i] != nullptr && coins[i]->GetTimer() == -1 && coins[i]->GetID() == i)
			{
				cout << ">ID: " << coins[i]->GetID() << " for: " << i << endl;
				coins[i]->Drop(go);
				coinCount--;
				return;
			}
		}
	}
}

void Game::DeleteCoin(vector<Coin*>&)
{
	// WIP
}

void Game::CheckCoin(vector<Coin*> coins, Player& player)
{
	for (int i = 0; i < coins.size(); i++)
	{
		if (coinCount < 10)
		{
			//cout << abs(coins[i]->dst.x - player.m_rDst.x) << endl;
			if (abs(coins[i]->dst.x - player.m_rDst.x) <= 32 && coins[i]->CanPickup() && coins[i]->GetTimer() >= 200)
			{
				//cout << "Coin slot: " << i << " is being carried." << endl;
				coins[i]->Pickup(coinCount);
				//coinPouch[j] = coins[i];// new Coin(player, true);
				//coinPouch[j]->Pickup(i, player);
				//coins[j] = nullptr;
				//j = 10; i = coins.size();
				coinCount++;
			}
			else
			{
				//cout << "> " << abs(coins[i]->m_x - player.m_x) << endl << coins[i]->CanPickup() << endl << (coinPouch[9] == nullptr ? "true" : "false") << endl;
			}
		}
	}
}


void Game::CoinStats()
{
	for (int i = 0; i < coins.size(); i++)
	{
		cout << "Can pickup coin " << i << ": " << coins[i]->CanPickup() << endl << "X: " << coins[i]->dst.x << " Y: " << coins[i]->dst.y << endl << coins[i]->GetTimer() << endl;
	}
}

//Enemy
void Game::SpawnEnemy(GameObject& go)
{
	Enemy enemy = new Enemy();
}