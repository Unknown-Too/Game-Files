#pragma once
#include "Camera.h"
#include "Background.h"

class Parallax
{
public:
	Background Background1, Background2, Ground, Sky, Clouds;

	void LoadImages(SDL_Renderer* renderer)
	{
		IMG_Init(IMG_INIT_PNG);
		//Background1
		Background1.m_sBackground = IMG_Load("Images/Background/Background1.png");
		if (Background1.m_sBackground == 0)
		{
			std::cout << "Background1 load fail" << std::endl;
		}
		Background1.m_tBackground = SDL_CreateTextureFromSurface(renderer, Background1.m_sBackground);
		Background1.m_rBackgroundDst.w = Background1.m_rBackgroundSrc.w; Background1.m_rBackgroundDst.h = Background1.m_rBackgroundSrc.h;
		Background1.m_rBackgroundDst.x = 0; Background1.m_rBackgroundDst.y = 0;
		//Background2
		Background2.m_sBackground = IMG_Load("Images/Background/Background2.png");
		if (Background2.m_sBackground == 0)
		{
			std::cout << "Background2 load fail" << std::endl;
		}
		Background2.m_tBackground = SDL_CreateTextureFromSurface(renderer, Background2.m_sBackground);
		Background2.m_rBackgroundDst.w = Background2.m_rBackgroundSrc.w; Background2.m_rBackgroundDst.h = Background2.m_rBackgroundSrc.h;
		Background2.m_rBackgroundDst.x = 0; Background2.m_rBackgroundDst.y = 0;
		//Ground
		Ground.m_sBackground = IMG_Load("Images/Background/Ground.png");
		if (Ground.m_sBackground == 0)
		{
			std::cout << "Ground load fail" << std::endl;
		}
		Ground.m_tBackground = SDL_CreateTextureFromSurface(renderer, Ground.m_sBackground);
		Ground.m_rBackgroundDst.w = Ground.m_rBackgroundSrc.w; Ground.m_rBackgroundDst.h = Ground.m_rBackgroundSrc.h;
		Ground.m_rBackgroundDst.x = 0; Ground.m_rBackgroundDst.y = 0;
		//Sky
		Sky.m_sBackground = IMG_Load("Images/Background/Sky.png");
		if (Sky.m_sBackground == 0)
		{
			std::cout << "Sky load fail" << std::endl;
		}
		Sky.m_tBackground = SDL_CreateTextureFromSurface(renderer, Sky.m_sBackground);
		Sky.m_rBackgroundDst.w = Sky.m_rBackgroundSrc.w; Sky.m_rBackgroundDst.h = Sky.m_rBackgroundSrc.h;
		Sky.m_rBackgroundDst.x = 0; Sky.m_rBackgroundDst.y = 0;
		//Clouds
		Clouds.m_sBackground = IMG_Load("Images/Background/Clouds.png");
		if (Clouds.m_sBackground == 0)
		{
			std::cout << "Clouds load fail" << std::endl;
		}
		Clouds.m_tBackground = SDL_CreateTextureFromSurface(renderer, Clouds.m_sBackground);
		Clouds.m_rBackgroundDst.w = Clouds.m_rBackgroundSrc.w; Clouds.m_rBackgroundDst.h = Clouds.m_rBackgroundSrc.h;
		Clouds.m_rBackgroundDst.x = 0; Clouds.m_rBackgroundDst.y = 0;

		std::cout << "Loaded Parallax Images" << std::endl;
	}

	void Layer1(Camera& camera)
	{
		Ground.m_rBackgroundDst.x = Ground.m_x - camera.camera.x * 1;
	}
	void Layer2(Camera& camera)
	{
		Background1.m_rBackgroundDst.x = Background1.m_x - camera.camera.x * 0.8;
	}
	void Layer3(Camera& camera)
	{
		Background2.m_rBackgroundDst.x = Background2.m_x - camera.camera.x * 0.5;
	}
	void Layer4(Camera& camera)
	{
		Clouds.m_rBackgroundDst.x = Clouds.m_x - camera.camera.x * 0.2;
	}
	void Layer5(Camera& camera)
	{
		Sky.m_rBackgroundDst.x = Sky.m_x - camera.camera.x * 0;
	}

	void ParallaxEverything(Camera& camera)
	{
		Layer1(camera);
		Layer2(camera);
		Layer3(camera);
		Layer4(camera);
		Layer5(camera);

		//std::cout << "Parallaxing everything" << std::endl;
	}
};