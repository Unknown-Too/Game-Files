#include <chrono>
#include <iostream>
#include "Game.h"
#include "Player.h"
using namespace std;
using namespace chrono;

bool Game::init(const char* title, int xpos, int ypos, int width,
	int height, int flags)
{
	// Attempt to initialize SDL.
	if (SDL_Init(SDL_INIT_EVERYTHING) == 0)
	{
		cout << "SDL init success" << endl;
		// Init the window.
		m_pWindow = SDL_CreateWindow(title, xpos, ypos, width, height, flags);
		if (m_pWindow != 0) // Window init success.
		{
			cout << "Window creation successful" << endl;
			m_pRenderer = SDL_CreateRenderer(m_pWindow, -1, 0);
			if (m_pRenderer != 0) // Renderer init success.
			{
				cout << "renderer creation success" << endl;
				SDL_SetRenderDrawColor(m_pRenderer, 0, 0, 0, 255);
			}
			else
			{
				cout << "renderer init fail" << endl;
				return false; // Renderer init fail.
			}
		}
		else
		{
			cout << "window init fail" << endl;
			return false; // Window init fail.
		}
		IMG_Init(IMG_INIT_PNG); // Initializing image system.
		m_sPlayer = IMG_Load("Images/Player.png");
		if (m_sPlayer == 0)
		{
			cout << "player load fail" << endl;
			return false;
		}
		m_tPlayer = SDL_CreateTextureFromSurface(m_pRenderer, m_sPlayer);
		m_sTile = IMG_Load("Images/Tiles.png");
		if (m_sTile == 0)
		{
			cout << "tile load fail" << endl;
			return false;
		}
		m_tTile = SDL_CreateTextureFromSurface(m_pRenderer, m_sTile);

		background.m_sBackground = IMG_Load("Images/Background/pixil-frame-1.png");
		if (background.m_sBackground == 0)
		{
			cout << "background load fail" << endl;
			return false;
		}
		background.m_tBackground = SDL_CreateTextureFromSurface(m_pRenderer, background.m_sBackground);
		background.m_rBackgroundDst.w = background.m_rBackgroundSrc.w;
		background.m_rBackgroundDst.h = background.m_rBackgroundSrc.h;
		background.m_rBackgroundDst.x = 0;
		background.m_rBackgroundDst.y = 0;
	}
	else
	{
		cout << "SDL init fail" << endl;
		return false; // SDL init fail.
	}
	cout << "init success" << endl;
	m_bRunning = true; // Everything is okay, start the engine.
	return true;
}

bool Game::running()
{
	return m_bRunning;
}

bool Game::tick()
{
	auto duration = steady_clock::now().time_since_epoch();

	auto count = duration_cast<microseconds>(duration).count();
	int tick = 1000000 / m_iFPS;

	if (count % tick < 100)
	{
		if (m_bGotTick == false)
		{
			m_bGotTick = true;
			//cout << "Tick " << tick << " @ " << count << endl;
			return true;
		}
		return false;
	}
	else m_bGotTick = false;
	return false;
}

void Game::update(Player& p)
{
	camera.setCamera(p);

	background.m_rBackgroundDst.x = background.m_x - camera.camera.x;
	background.m_rBackgroundDst.y = background.m_y - camera.camera.y;

	//cout << "player x y: " << p.m_x << " " << p.m_y << endl;


	if (m_bLeftPressed)
	{
		p.MoveX(-1);
		p.m_bRight = false;
	}
	if (m_bRightPressed)
	{
		p.MoveX(1);
		p.m_bRight = true;
	}

	if (m_bSpeedUp)
	{
		p.m_iSpeed++;
		m_bSpeedUp = false;
	}

	if (m_bUpPressed || m_bDownPressed || m_bLeftPressed || m_bRightPressed)
	{
		if (m_iTickCtr == m_iTickMax)
		{
			m_iTickCtr = 0;
			p.AdvanceAnim();
		}
		m_iTickCtr++;
	}
	else
	{
		m_iTickCtr = 0;
		p.SetIdle();
	}

	if (p.m_x >= 7667) p.m_x = 7667;
	if (p.m_x <= 495) p.m_x = 495;
	if (p.m_y != 630) p.m_y = 630;
	if (p.m_y < 0) p.m_y = 0;
}

void Game::handleEvents(Player& p)
{
	SDL_Event event;

	while (SDL_PollEvent(&event))
	{
		switch (event.type)
		{
		case SDL_QUIT:
			m_bRunning = false;
			break;
		case SDL_KEYDOWN:
			switch (event.key.keysym.sym)
			{
			case 'w':
			case 'W':
				m_bUpPressed = true;
				break;
			case 's':
			case 'S':
				m_bDownPressed = true;
				break;
			case 'a':
			case 'A':
				m_bLeftPressed = true;
				break;
			case 'd':
			case 'D':
				m_bRightPressed = true;
				break;
			case 'e':
			case 'E':
				cout << p.m_x << " " << p.m_y << endl << p.m_rDst.x << " " << p.m_rDst.y << endl << p.m_iSpeed << endl << endl;
				break;
			case '=':
				m_bSpeedUp = true;
				break;
			}
			break;
		case SDL_KEYUP:
			switch (event.key.keysym.sym)
			{
			case 'w':
			case 'W':
				m_bUpPressed = false;
				break;
			case 's':
			case 'S':
				m_bDownPressed = false;
				break;
			case 'a':
			case 'A':
				m_bLeftPressed = false;
				break;
			case 'd':
			case 'D':
				m_bRightPressed = false;
				break;
			}
			break;
		}
	}
}

void Game::render(Player& p)
{
	SDL_RenderClear(m_pRenderer);
	SDL_RenderCopy(m_pRenderer, background.m_tBackground, &background.m_rBackgroundSrc, &background.m_rBackgroundDst);
	SDL_RenderCopyEx(m_pRenderer, m_tPlayer, p.GetSrc(), p.GetDst(), 0, 0, (p.m_bRight ? SDL_FLIP_NONE : SDL_FLIP_HORIZONTAL));
	SDL_RenderPresent(m_pRenderer);
}

void Game::clean()
{
	SDL_DestroyTexture(m_tPlayer);
	SDL_DestroyTexture(m_tTile);
	SDL_FreeSurface(m_sPlayer);
	SDL_FreeSurface(m_sTile);
	SDL_DestroyRenderer(m_pRenderer);
	SDL_DestroyWindow(m_pWindow);
	IMG_Quit();
	SDL_Quit();
}