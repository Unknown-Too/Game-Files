#pragma once
#include "Parallax.h"

class DayNightCycle : Parallax
{
private:
	Uint8 r = 0, g = 100, b = 255;
	float time = 0;
	int count = 0;
	bool a = true;
public:
	void Cycle()
	{
		// Day night cycle ;)
		if (count == 10)
		{
			count = 0;
			time++;

			if (time >= 0 && time <= 100)
			{
				g--;
			}
			if (time >= 100 && time <= 300 && b < 256 && b > 1)
			{
				b -= 2;
			}
			if (time >= 160 && time <= 240 && r < 80)
			{
				r++;
			}
			if (time >= 200 && time <= 280 && r > 0)
			{
				r--;
			}
			if (time >= 450 && time < 500 && r <= 50)
			{
				r++;
			}
			if (time >= 500 && time <= 550 && r > 0)
			{
				r--;
			}
			if (time >= 500 && time <= 755 && b < 255)
			{
				b++;
			}
			if (time >= 550 && time <= 650)
			{
				g++;
			}
			if (time >= 800)
			{
				time = 0;
			}
			//std::cout << "r: " << unsigned(r) << " g: " << unsigned(g) << " b: " << unsigned(b) << " time: " << time << std::endl;
		}
		count++;



		/* //This was the rainbow sky test
		if (r > 0 && g != 255 && a)
		{
			r--;
			g++;
			std::cout << "R-- " << unsigned(r) << " G++ " << unsigned(g) << std::endl;
		}
		else if (g > 0 && b != 255)
		{
			g--;
			b++;
			std::cout << "G-- " << unsigned(g) << " B++ " << unsigned(b) << std::endl;
		}
		else if (b > 0 && r != 255)
		{
			b--;
			r++;
			std::cout << "B-- " << unsigned(b) << " R++ " << unsigned(r) << std::endl;
		}

		if (b == 0)
			a = true;
		else
			a = false;*/

	}

	Uint8 GetR()
	{
		return r;
	}
	Uint8 GetG()
	{
		return g;
	}
	Uint8 GetB()
	{
		return b;
	}
};

class Moon
{
private:
	int x, y;
public:

};