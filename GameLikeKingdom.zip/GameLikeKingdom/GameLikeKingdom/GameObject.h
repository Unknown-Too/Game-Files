#pragma once


class GameObject
{
public:
	// Every GameObject has an x and y position
	int m_x;
	int m_y;
	// Most will have a width and height but not all so set to 0
	int m_w = 0;
	int m_h = 0;
};