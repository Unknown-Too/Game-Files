#pragma once
#include "SDL.h"
#include "SDL_image.h"
#include "GameObject.h"

class Background : public GameObject
{
public:
	SDL_Surface* m_sBackground;
	SDL_Texture* m_tBackground;
	SDL_Rect m_rBackgroundSrc = { 0, 0, 8192, 768 };
	SDL_Rect m_rBackgroundDst;
};