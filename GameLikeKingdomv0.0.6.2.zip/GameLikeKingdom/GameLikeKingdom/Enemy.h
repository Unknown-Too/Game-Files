#ifndef _ENEMY_H
#define _EMENY_H

#include "Sprite.h"
#include "Coin.h"
#include "Game.h"
#include <vector>
#include <iostream>

#define WIDTH 60
#define HEIGHT 80

class Enemy : public Sprite
{
private:

	void UpdateDst()
	{
		m_rDst.x = m_x;
		m_rDst.y = m_y;
	}

	int m_maxHP = 100;

public:
	int m_iSpeed;
	int m_iFrameCtr = 0;
	int m_iFrameMax = 4;
	int m_currentHP;
	int target_x;
	bool m_bRight = true;
	SDL_Rect m_rSrc;
	SDL_Rect m_rDst;
	SDL_Texture* m_pTexture;
	bool alive;
	bool collision;
	bool tookCoin;

	Enemy(GameObject& go, double x, double y, SDL_Renderer* r, SDL_Texture* t)
	{
		//Declare position values, size, and speed
		m_x = x;
		m_y = y;
		m_iSpeed = 85;
		m_rSrc = { 0, 0, 32, 32 };

		//Sprite drawing
		m_w = m_rSrc.w = WIDTH;
		m_h = m_rSrc.h = HEIGHT;
		m_rDst.w = WIDTH;
		m_rDst.h = HEIGHT;
		SetImage(r, t);

		//Actions during lifecycle
		Spawn(go);
		Seek(go);
		enemyAttack(go);

		UpdateDst();
	}

	~Enemy() {}

	void Seek(GameObject& go)
	{
		//Create a vector in the direction that you want the enemy to move.That's easy:
		int target_x = go.m_x - m_x;
		//Move towards Player
		m_x += (target_x * m_iSpeed) / 10;

		if (m_x == go.m_x || m_x == (go.m_x - go.m_w))
		{
			collision = true;
		}
	}

	void Spawn(GameObject& go)
	{
		//Where to appear - off-screen, to the right of Player(?)
		m_x = (go.m_x + go.m_w / 2) - (SCREEN_WIDTH);
		std::cout << "Enemy @ " << m_x << std::endl;
		alive = true;
	}

	void enemyAttack(GameObject& go)
	{
		// attack, while you're alive, until either you or Player is dead
		while (collision == true && go.m_currentHP > 0 && m_currentHP > 0)
		{
			go.m_currentHP -= 10;
		}
	}

	const SDL_Rect* GetSrc() { return &m_rSrc; }
	const SDL_Rect* GetDst() { return &m_rDst; }

	void AdvanceAnim()
	{
		m_iFrameCtr++;

		if (m_iFrameCtr == m_iFrameMax)
		{
			m_iFrameCtr = 0;
		}
		m_rSrc.x = WIDTH * m_iFrameCtr;
	}

};
#endif