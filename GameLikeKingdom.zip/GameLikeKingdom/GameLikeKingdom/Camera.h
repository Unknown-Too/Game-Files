#pragma once
#include "SDL.h"
#include "SDL_image.h"

const int SCREEN_WIDTH = 1024;
const int SCREEN_HEIGHT = 768;

const int LEVEL_WIDTH = 10000;
const int LEVEL_HEIGHT = 768;

class Camera
{
public:
	SDL_Rect camera = { 0, 0, SCREEN_WIDTH, SCREEN_HEIGHT };

	void setCamera(GameObject go)
	{
		camera.x = (go.m_x + go.m_w / 2) - (SCREEN_WIDTH) / 2;
		camera.y = (go.m_y + go.m_h / 2) - (SCREEN_HEIGHT) / 2;

		//std::cout << "set camera: " << camera.x << " " << camera.y << std::endl;

		//Keep the camera in bounds.
		if (camera.x < 0)
		{
			camera.x = 0;
		}
		if (camera.y < 0)
		{
			camera.y = 0;
		}
		if (camera.x > LEVEL_WIDTH - camera.w)
		{
			camera.x = LEVEL_WIDTH - camera.w;
		}
		if (camera.y > LEVEL_HEIGHT - camera.h)
		{
			camera.y = LEVEL_HEIGHT - camera.h;
		}
	}
};